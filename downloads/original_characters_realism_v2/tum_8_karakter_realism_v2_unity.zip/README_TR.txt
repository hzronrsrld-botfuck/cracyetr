SEKİZ KARAKTER V2 - UNITY TOPLU PAKET

İçerik: Savaşçı, Ninja, Şaman ve Sura; kadın ve erkek sürümleri.
Her klasörde gömülü dokulu FBX, önizleme ve doğrulama raporu bulunur.
İskelet: 52 Mixamo kemiği + Root, 30 parmak kemiği ve 5 ekipman bağlantısı.
Yürüyüş animasyonu FBX içine gömülüdür.

Unity: FBX > Rig > Animation Type = Humanoid > Avatar Definition = Create From This Model

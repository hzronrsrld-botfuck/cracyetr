BİZİM OLUŞTURDUĞUMUZ ANATOMİK KARAKTERLER

Bu paket Ch36 veya sonradan yüklenen başka bir karakteri içermez.
Karakter Blender dosyası, önizleme ve doğrulama raporuyla birlikte verilmiştir.
Blender 4.x ile açabilirsiniz.

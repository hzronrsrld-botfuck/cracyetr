# Ch36 tabanlı karakter seti

- Sınıflar: Savaşçı, Ninja, Şaman, Sura
- Cinsiyet: erkek ve kadın
- Her karakter: 86.640 gövde vertexi, 52 Mixamo kemiği, 30 parmak kemiği
- Çıktılar: Blender ve gömülü dokulu FBX
- Ekipman noktaları: SOCKET_Weapon_R, SOCKET_Weapon_L, SOCKET_Back, SOCKET_Hip_R, SOCKET_Hip_L
- Koleksiyonlar: CHARACTER_CORE, FACE_DETAILS, HAIR_SLOT, EQUIPMENT_SOCKETS
- Kıyafet ve silah eklenmedi; sınıf ekipmanları sonradan takılabilir.

Unity'de FBX Rig sekmesinde Animation Type = Humanoid seçip Avatar Definition = Create From This Model kullanın.
